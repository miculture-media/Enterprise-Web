<!DOCTYPE html>
<html lang="en">
<head>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
require "databaseinit.php";
if (isset($_POST['addingCourse']))
{
	        $courseName= $_POST['coursename'];
			$facultyID = $_POST['facultyId'];

	mysql_query("INSERT INTO `course` (`course_name`,`faculty_id`) 
	VALUES ('$courseName','$facultyID');")
	or die(mysql_error()); 
	
	
	header("Location: adminIndex.php");
}
	
	session_start();
   if(!isset($_SESSION['sess_user']))
   {
	header("Location: adminIndex.php");
	}
else
{
}
?>
<title>Add Course</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/courses.css">
<link rel="stylesheet" type="text/css" href="styles/courses_responsive.css">
</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			
		<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
									<li><div class="question">Have any questions?</div></li>
									<li>
										<i class="fa fa-phone" aria-hidden="true"></i>
										<div>+260 211 *** ***</div>
									</li>
									<li>
										<i class="fa fa-envelope-o" aria-hidden="true"></i>
										<div>info@goldendistrict.uni</div>
									</li>
								</ul>
								<div class="top_bar_login ml-auto">
									<div class="login_button"><a href="logout.php">Logout</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

		<!-- Header Content -->
		<div class="header_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo_container">
								<a href="adminIndex.html">
									<div class="logo_text">Golden District<span> University</span></div>
								</a>
							</div>
							<nav class="main_nav_contaner ml-auto">
								<ul class="main_nav">
									<li><a href="adminIndex.html">Home</a></li>
									<li><a href="addUser.php">Dashboard</a></li>
									<li><a href="addUser.php">Add User</a></li>
									<li ><a href="addFaculty.php">Add Faculty</a></li>
									<li class="active"><a href="addCourse.php">Add Course</a></li>
									<li><a href="#">Page</a></li>
								</ul>
								<div class="search_button"><i class="fa fa-search" aria-hidden="true"></i></div>

								<!-- Hamburger -->

								<div class="hamburger menu_mm">
									<i class="fa fa-bars menu_mm" aria-hidden="true"></i>
								</div>
							</nav>


						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Header Search Panel -->
		<div class="header_search_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_search_content d-flex flex-row align-items-center justify-content-end">
							<form action="#" class="header_search_form">
								<input type="search" class="search_input" placeholder="Search" required="required">
								<button class="header_search_button d-flex flex-column align-items-center justify-content-center">
									<i class="fa fa-search" aria-hidden="true"></i>
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>			
		</div>			
	</header>

	<!-- Menu -->

	<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
		<div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
		<div class="search">
			<form action="#" class="header_search_form menu_mm">
				<input type="search" class="search_input menu_mm" placeholder="Search" required="required">
				<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
					<i class="fa fa-search menu_mm" aria-hidden="true"></i>
				</button>
			</form>
		</div>																			
		<nav class="menu_nav">
			<ul class="menu_mm">
				<li class="menu_mm"><a href="adminIndex.php">Home</a></li>
				<li class="menu_mm"><a href="addUser.php">Dashboard</a></li>
				<li class="menu_mm"><a href="addUser.php">Add User</a></li></li>
			</ul>
		</nav>
	</div>
	
	<!-- Home -->

	<div class="home">
		<div class="breadcrumbs_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="breadcrumbs">
							<ul>
								<li><a href="adminIndex.html">Home</a></li>
								<li>Users</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>

	<!-- Courses -->

	<div class="courses">
		<div class="container">
			<div class="row">

				<!-- Courses Main Content -->
				<div class="col-lg-8">
					
					<div class="courses_container">
						<div class="row courses_row">
							
							<!-- Database Entry -->
							<div class="col-lg-12 course_col">
								<div class="course">
									<div class="course_body">
										<div class="course_teacher">Add Course</div>
										<div class="course_text">
										<form method="POST">

				<p id="float-container" class="float-container">
					<label for="coursename">Course Name</label><br>
					<input id="coursename" name="coursename" type="text">
				</p>

				<p id="float-container" class="float-container">
					<label for="facultyId">Faculty ID</label><br>
					</p>
					<p>
				        <select name="facultyId" class="courses_search_select courses_search_input">
                          <option value="101">Business</option>
                          <option value="102">Sciences</option>
                          <option value="103">Mathematics</option>
                       </select> 
				    </p>
				
			<br>
			<input type="submit" value="Submit" name="addingCourse">
		</form>
										</div>
									</div>
								</div>
							</div>
						</div>	
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	

			<div class="row copyright_row">
				<div class="col">
					<div class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
						<div class="cr_text"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
						<div class="ml-lg-auto cr_links">
							<ul class="cr_list">
								<li><a href="#">Copyright notification</a></li>
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/courses.js"></script>
</body>
</html>