<?php

//creating variables for db sign in and db name
$errmessage = "Connection could not be established";
$mysql_db = "central_university";
//myPhpAdmin credentials
$mysql_hostName = "localhost";
$mysql_userName = "root";
$mysql_password = "";

//connection to myPhpAdmin	
$connect = mysql_connect($mysql_hostName, $mysql_userName, $mysql_password);  

//selecting the database
$database = mysql_select_db($mysql_db,$connect);
?>

<?php

//Sample Data

//ADDING THE ADMINISTRATOR
//username = admin
//password = strongpassword
$create_admin="INSERT INTO `users` (`fname`,`surname`, `gender`, `email`, `accountType`, `password`) 
	VALUES ('admin','1', 'male', 'admin@cutc.com', 'admin', 'strongpassword');";
		$return = mysql_query($create_admin, $connect);
		
//ADDING THE MARKETING MANAGER
//username = marketingMg
//password = strongpassword
$create_marketingAdmin="INSERT INTO `users` (`fname`,`surname`, `gender`, `email`, `accountType`, `password`) 
	VALUES ('marketingMg','1', 'male', 'marketingmg@cutc.com', 'admin', 'strongpassword');";
	$return = mysql_query($create_marketingAdmin, $connect);
		
//ADDING THE GUEST
//username = guest
//password = strongpassword
$create_marketingAdmin="INSERT INTO `users` (`fname`,`surname`, `gender`, `email`, `accountType`, `password`) 
	VALUES ('guest','1', 'male', 'guest@cutc.com', 'guest', 'strongpassword');";
	$return = mysql_query($create_marketingAdmin, $connect);
		
?>