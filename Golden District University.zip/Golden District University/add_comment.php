<?php
error_reporting(E_ALL ^ E_DEPRECATED);
require "databaseinit.php";

if(isset($_POST['comments'])){
	$id1 =preg_replace('#[^0-9]#', '', $_POST['id']);
	$comment = mysqli_real_escape_string($conx,$_POST['com']);

	if(empty($comment){
		echo "Please add comment to continue";
					exit();
	} else{
		$sql="UPDATE faculty SET cood_comment ='$comment' WHERE faculty_id='$id1'";
					$query=mysqli_query($conx,$sql);
					echo '
						<script type="text/javascript">
							alert("Commented added");
							window.location = "coo_report.php";
						</script>
					
					';
	}

}
?>