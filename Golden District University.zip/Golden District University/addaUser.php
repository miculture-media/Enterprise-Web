<!DOCTYPE html>
<html lang="en">
<head>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
require "databaseinit.php";

if (isset($_POST['addingUser']))
{
		//preparing variables for use to post to the database
	$fname = $_POST['fname'];
	$surname = $_POST['surname'];
	$gender = $_POST['gender'];
	$email = $_POST['email'];
	$accountType = $_POST['accountType'];
	$password1 = $_POST['password1'];
//adding user to database
	mysql_query("INSERT INTO `users` (`fname`, `surname`, `gender`, `email`, `accountType`, `password`) 
	VALUES ('$fname', '$surname', '$gender', '$email', '$accountType', '$password1') ;")
	or die(mysql_error()); 
	
	
	
	header("Location: adminIndex.php");
}
	
//session_start();
 //  if(!isset($_SESSION['sess_user']))
   //{
	//header("Location: adminHome.php");
//	}
else
{
}

?>
<title>User</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/courses.css">
<link rel="stylesheet" type="text/css" href="styles/courses_responsive.css">
</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			
		<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
									<div class="top_bar_login ml-auto">
									<div class="login_button"><a href="logout.php">Logout</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

		<!-- Header Content -->
		<div class="header_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo_container">
								<a href="#">
									<div class="logo_text">Golden District<span> University</span></div>
								</a>
							</div>
							<nav class="main_nav_contaner ml-auto">
								<ul class="main_nav">
									<li><a href="adminIndex.php">Dashboard</a></li>
									<li class="active"><a href="addaUser.php">Add User</a></li>
									<li><a href="addFaculty.php">Add Faculty</a></li>
									<li><a href="#">Add Course</a></li>
									<li><a href="#">Page</a></li>
								</ul>
								<div class="search_button"><i class="fa fa-search" aria-hidden="true"></i></div>

								<!-- Hamburger -->

								<div class="hamburger menu_mm">
									<i class="fa fa-bars menu_mm" aria-hidden="true"></i>
								</div>
							</nav>


						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Header Search Panel -->
		<div class="header_search_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_search_content d-flex flex-row align-items-center justify-content-end">
							<form action="#" class="header_search_form">
								<input type="search" class="search_input" placeholder="Search" required="required">
								<button class="header_search_button d-flex flex-column align-items-center justify-content-center">
									<i class="fa fa-search" aria-hidden="true"></i>
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>			
		</div>			
	</header>

	<!-- Menu -->

	<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
		<div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
		<div class="search">
			<form action="#" class="header_search_form menu_mm">
				<input type="search" class="search_input menu_mm" placeholder="Search" required="required">
				<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
					<i class="fa fa-search menu_mm" aria-hidden="true"></i>
				</button>
			</form>
		</div>																			
		<nav class="menu_nav">
			<ul class="menu_mm">
				<li class="menu_mm"><a href="adminIndex.php">Home</a></li>
				<li class="menu_mm"><a href="addUser.php">Dashboard</a></li>
				<li class="menu_mm"><a href="addUser.php">Add User</a></li></li>
			</ul>
		</nav>
	</div>
	
	<!-- Home -->

	<div class="home">
		<div class="breadcrumbs_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="breadcrumbs">
							<ul>
								<li><a href="index.html">Home</a></li>
								<li>Add a User</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>

	<!-- Courses -->

	<div class="courses">
		<div class="container">
			<div class="row">

				<!-- Courses Main Content -->
				<div class="col-lg-8">
										<div class="courses_container">
						<div class="row courses_row">
							
							<!-- Database Entry -->
							<div class="col-lg-12 course_col">
								<div class="course">
									<div class="course_body">
										<div class="course_text">
										
										<h2 class="section_title">Add User</h2><br><br>


					<form method="POST" id="signupStudent">

				<p id="float-container" class="float-container">
					<label for="fname">First Name</label><br>
					<input id="fname" name="fname" type="text">
				</p>

				<p id="float-container" class="float-container">
					<label for="surname">Last Name</label><br>
					<input name="surname" type="text">
				</p>

				<p id="float-container" class="float-container" >
					<label for="gender">Gender</label><br><br>
					<input name="gender" type="radio" name="gen" value="Male">Male<br><br>
					<input name="gender" type="radio" name="gen" value="Male">Female<br><br>
				</p>
				
				<p id="float-container" class="float-container">
					<label for="email">Email</label><br>
					<input name="email" type="email">
				</p>

				<p id="float-container" class="float-container">
					<label for="accountType">Account Type</label><br><br>
					<input name="accountType" type="radio" name="gen" value="Student">Student<br><br>
					<input name="accountType" type="radio" name="gen" value="Marketing Co-Ord">Marketing Co-Ordinator<br><br>
					<input name="accountType" type="radio" name="gen" value="marketing_manager">Marketing Manager<br><br>

				</p>
				
				<p id="float-container" class="float-container">
					<label for="password1">Password</label><br>
					<input name="password1" type="password">
				</p>

				<p id="float-container" class="float-container">
					<label for="password2">Confirm Password</label><br>
					<input name="password2" type="password">
				</p>
			</div>	
			<br>
			<input type="submit" value="Submit" name="addingUser">
		</form>



										</div>
									</div>
								</div>
							</div>
						</div>	
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	

			<div class="row copyright_row">
				<div class="col">
					<div class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
						<div class="cr_text"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
						<div class="ml-lg-auto cr_links">
							<ul class="cr_list">
								<li><a href="#">Copyright notification</a></li>
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/courses.js"></script>
</body>
</html>