<!DOCTYPE html>
<html lang="en"><!-- Page for the marketing manager's comprehensive report but cannnot edit any publication, can only download -->
<head>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
require "databaseinit.php";

session_start();
$_SESSION['accountType'];
$_SESSION['uname'];

?>
<title>Dashboard</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/courses.css">
<link rel="stylesheet" type="text/css" href="styles/courses_responsive.css">
</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			
		<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
									<li><div class="question">Have any questions?</div></li>
									<li>
										<i class="fa fa-phone" aria-hidden="true"></i>
										<div>+260 211 *** ***</div>
									</li>
									<li>
										<i class="fa fa-envelope-o" aria-hidden="true"></i>
										<div>info@goldendistrict.uni</div>
									</li>
								</ul>
								<div class="top_bar_login ml-auto">
									<div class="login_button"><a href="logout.php">Logout</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

		<!-- Header Content -->
		<div class="header_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo_container">
								<a href="#">
									<div class="logo_text">Golden District<span> University</span></div>
								</a>
							</div>
							<nav class="main_nav_contaner ml-auto">
								<ul class="main_nav">
									<li><a href="all_report.php">Dashboard</a></li>
									<li class="active"><a href="all_report.php">Reports</a></li>
									
								</ul>
								
								<!-- Hamburger -->

								<div class="hamburger menu_mm">
									<i class="fa fa-bars menu_mm" aria-hidden="true"></i>
								</div>
							</nav>


						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Header Search Panel -->
		<div class="header_search_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_search_content d-flex flex-row align-items-center justify-content-end">
							<form action="#" class="header_search_form">
								<input type="search" class="search_input" placeholder="Search" required="required">
								<button class="header_search_button d-flex flex-column align-items-center justify-content-center">
									<i class="fa fa-search" aria-hidden="true"></i>
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>			
		</div>			
	</header>

	<!-- Menu -->

	<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
		<div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
		<div class="search">
			<form action="#" class="header_search_form menu_mm">
				<input type="search" class="search_input menu_mm" placeholder="Search" required="required">
				<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
					<i class="fa fa-search menu_mm" aria-hidden="true"></i>
				</button>
			</form>
		</div>																			
		<nav class="menu_nav">
			<ul class="menu_mm">
				<li class="menu_mm"><a href="all_report.php">Dashboard</a></li>
				<li class="menu_mm"><a href="logout.php">Logout</a></li></li>
			</ul>
		</nav>
	</div>
	
	<!-- Home -->

	<div class="home">
		<div class="breadcrumbs_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="breadcrumbs">
							<ul>
								<li><a href="adminIndex.php">Home</a></li>
								<li>Dashboard</li>
								<li>Logged in as: <?php echo $_SESSION['uname'];
								?></li>
								<li>Account Type: <?php echo $_SESSION['accountType']; ?></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>

	<!-- Courses -->

	<div class="courses">
		<div class="container">
			<div class="row">

				<!-- Courses Main Content -->
				<div class="col-lg-12">
					
					<div class="courses_container">
						<div class="row courses_row">
							
							<!-- Database Entry -->
							<div class="col-lg-12 course_col">
								<div class="course">
									<div class="course_body">
										<h3 class="course_title"><a href="#">All Contributions from all Faculties</a></h3>
										<div class="course_text">Note: Only Contributions with Comments can be downloaded.
										<form id="sectionreport" name="download-report" method="post" action="download.php">
										<?php  
												  //include_once("conx/conx.php");
												 $rowx = '';
												 $output = '';  
												 $sql = "SELECT faculty_id, contribution_title, image, submittedDate, cood_comment FROM faculty WHERE contribution_title IS NOT NULL AND cood_comment IS NOT NULL ORDER BY faculty_id DESC";  
												 $result = mysql_query($sql);  
												 $output .= '  
													  <div >  
														   <table class="table">  
																<tr>  
																	<strong> <th >Title</th>  
																	 <th >Submission Date</th>
																	 <th >Co-Ordinator Comment</th> </strong>
																	 
																</tr>';  
												 if(mysql_num_rows($result) > 0)  
												 {  
													  while($row = mysql_fetch_array($result))  
													  {  
														   $output .= '  
																<tr>  
																	<td >'.$row["contribution_title"].'</td>
																	<td >'.$row["submittedDate"].'</td>
																	<td >'.$row["cood_comment"].'</td>
													  
																</tr>  
														   ';  
													  }  
												 }  
												 else  
												 {  
													  $output .= '<tr>  
																		  <td colspan="4">No Registered Users</td>  
																	 </tr>';  
												 }  
												 $output .= '</table>  
													  </div>';  
												 echo $output;  
								 ?>

								 		<input type="submit" name="download_all" value="Download All" >
								 		</form>
										</div>
									</div>
								</div>
							</div>
						</div>	

						<div class="row courses_row">
						<!-- Database Entry -->
							<div class="col-lg-12 course_col">
								<div class="course">
									<div class="course_body">
										<h3 class="course_title"><a href="#">Total Contributions within each Faculty</a></h3>
										<div class="course_text">
										<?php  
												  //include_once("conx/conx.php");
												  $bettermsg = "No Contributions from Faculty yet.";
												 $output = '';  $temp = "";
												 $sql = "SELECT COUNT(faculty_id) AS fac_Num1, faculty_id, faculty_name FROM faculty WHERE contribution_title IS NOT NULL AND faculty_name = 'Science'";

												 $result = mysql_query($sql); 
												 $sci_fc = $row['fac_Num1']; 


												 $sql02 = "SELECT COUNT(faculty_id) AS fac_Num1 FROM faculty WHERE contribution_title IS NOT NULL AND faculty_name = 'Business'";

												 $result02 = mysql_query($sql02); 
												 $busi_fc = $row['fac_Num1'];

												 $sql03 = "SELECT COUNT(faculty_id) AS fac_Num1 FROM faculty WHERE contribution_title IS NOT NULL AND faculty_name = 'Biology'";

												 $result03 = mysql_query($sql03); 
												 $biol_fc = $row['fac_Num1'];

												 

									 
												 $output .= '  
													  <div >  
														   <table class="table">  
																<tr>  
																	 <th >Science Faculty</th>  
																	 <th >Business Faculty</th>  
																	 <th >Biology</th>																	 
																</tr>
																<tr>  
																	</tr>
																'; 
												if(mysql_num_rows($result) > 0)  
												 {  
													  while($row = mysql_fetch_array($result))  
													  {  
														   $output .= '  
																 
																<td >'.$row["fac_Num1"].' Contribution(s)</td>
														   ';  
													  }  
												 }if(mysql_num_rows($result02) > 0)  
												 {  
													  while($row = mysql_fetch_array($result02))  
													  {  
														   $output .= '  
																<td >'.$row['fac_Num1'].' Contribution(s)</td>											  
																  
														   ';  
													  }  
												 }	
												 if(mysql_num_rows($result03) > 0)  
												 {  
													  while($row = mysql_fetch_array($result03))  
													  {  
														   $output .= '  
																<td >'.$row['fac_Num1'].' Contribution(s)</td>											  
																  
														   ';  
													  }  
												 }			 
												  
											//	 else  
											//	 {  
											//		  $output .= '<tr>  
											//							  <td colspan="4">No Statistical Data available</td>  
											//						 </tr>';  
											//	 }  
												 $output .= '</table>  
													  </div>';  
												 echo $output; 
												echo $temp; 
								 ?>

										</div>
									</div>
								</div>
							</div>
						</div>
												
							
						</div>
						
						<!-- Courses Main Content -->
				<div class="col-lg-12">
					
					<div class="courses_container">
						<div class="row courses_row">
							
							<!-- Database Entry -->
							<div class="col-lg-12 course_col">
								<div class="course">
									<div class="course_body">
										<h3 class="course_title"><a href="#">Percentage of all Contributions from all Faculties</a></h3>
										<div class="course_text">
										<?php  
												  //include_once("conx/conx.php");
												 $output = '';  
												 $sql = "SELECT COUNT(contribution) AS sci_sum, faculty_id FROM faculty WHERE contribution_title IS NOT NULL AND faculty_name = 'Science'";  
												 $result = mysql_query($sql); 
												 //$row = mysqli_fetch_array($result);
												 $coutre = $row['sci_sum']; 

//$coutrex = '';

												 $sqlx = "SELECT COUNT(contribution) AS bio_sum, faculty_id FROM faculty WHERE contribution_title IS NOT NULL AND faculty_name = 'Biology'";  
												 $resultx = mysql_query($sqlx); 
												 //$row = mysqli_fetch_array($result);
												 $coutrex = $row['bio_sum'];

												  $sqly = "SELECT COUNT(contribution) AS bus_sum, faculty_id FROM faculty WHERE contribution_title IS NOT NULL AND faculty_name = 'Business'";  
												 $resulty = mysql_query($sqly); 
												 //$row = mysqli_fetch_array($result);
												 $coutrey = $row['bus_sum'];

												 $sqlz = "SELECT COUNT(contribution) AS Total_Contri FROM faculty WHERE contribution_title IS NOT NULL";  
												 $resultz = mysql_query($sqlz); 
												 //$row = mysqli_fetch_array($result);
												 $coutrez = $row['cont_sum'];

												 //calculation of science percentages
												 if($coutre != 0 || $coutrez != 0){	
													// $science_percent = ($row["sci_sum"]  / $row["cont_sum"]) * 100.0;
													$science_percent1 = get_percentage($row["sci_sum"]  / $row["cont_sum"]);
													$science_percent = number_format($science_percent1, 2);
													 }else{
													 	//$science_percent = 6;
													 	$science_percent = number_format( $coutrez, 2);
													 }

												//calculation of business percentages
												 if( $coutrey == 0 || $coutrez == 0){	
												 	$business_percent = 0;
													 //$business_percent = ($rowy['bus_sum'] / $coutre  ) * 100;
													;
													 }else{
													 	 $business_percent = (45 / 60  ) * 100;
													 }

													 //calculation of business percentages
												 if( $coutrey != 0 || $coutrez != 0){	
													 $biology_percent = ($row['bio_sum'] / $coutre  ) * 100;
													 }else{
													 	$biology_percent = 0;
													 }
													 	 

												 $output .= '  
													  <div >  
														   <table class="table">  
																<tr>  <th></th>
																	 <th >Total in Science</th>  
																	 <th >Total in Biology</th>
																	 <th >Total in Business</th>  
																	 
																</tr>';  
												 if(mysql_num_rows($result) > 0)  
												 {  
													  while($row = mysql_fetch_array($result))  
													  {  
														   $output .= '  
																<tr>  
																<th></th>	<td >'.$row["sci_sum"].'</td>												  
																  
														   ';  
													  }  
												 }if(mysql_num_rows($resultx) > 0)  
												 {  
													  while($rowx = mysql_fetch_array($resultx))  
													  {  
														   $output .= '
																	<td >'.$rowx["bio_sum"].'</td>												  
																
														   ';  
													  }  
												 }if(mysql_num_rows($resulty) > 0)  
												 {  
													  while($rowy = mysql_fetch_array($resulty))  
													  {  
														   $output .= '
																	<td >'.$rowy["bus_sum"].'</td>												  
																</tr>  
																<tr><th>Percentages : </th>
																<td >'.$science_percent.'%</td>
																<td>'.$business_percent.'%</td>
																<td>'.$biology_percent.'%</td>
																</tr>
														   ';  
													  }  
												 }  
												 else  
												 {  
													  $output .= '<tr>  
																		  <td colspan="4">No Registered Users</td>  
																	 </tr>';  
												 }  
												 $output .= '</table>  
													  </div>';  
												 echo $output;  
								 ?>
										</div>
									</div>
								</div>
							</div>
						</div>	

					

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


		

			<div class="row copyright_row">
				<div class="col">
					<div class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
						<div class="cr_text"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
						<div class="ml-lg-auto cr_links">
							<ul class="cr_list">
								<li><a href="#">Copyright notification</a></li>
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/courses.js"></script>
</body>
</html>