<?php

	session_start();
	
	include_once("conx2.php");
	//require "databaseinit.php";
	
	$admin_ok = false;
	$student_ok= false;
	$marketing_cood_ok = false;
	$marketing_manager_ok = false;
	$guest_ok = false;

	$log_id = "";
	$log_username ="";
	$log_password = "";

	$log_student_id = "";
	$log_student_username ="";
	$log_student_password = "";

	$log_marketing_cood_id = "";
	$log_marketing_cood_username ="";
	$log_marketing_cood_password = "";

	$log_marketing_manager_id = "";
	$log_marketing_manager_username ="";
	$log_marketing_manager_password = "";

	$log_guest_id = "";
	$log_guest_username ="";
	$log_guest_password = "";
	
	
	// this code checks the admin login status
	function admin_check($conx,$id,$u,$p){
		$sql = "SELECT fname FROM users WHERE accountType='admin' LIMIT 1";
		$query = mysqli_query($conx,$sql);
		$numrows = mysqli_num_rows($query);
		if($numrows > 0){
			return true;
		}
	}
	
	if (isset($_SESSION['user_id']) && isset($_SESSION['name']) && isset($_SESSION['password']) ){
		
		$log_id = $_SESSION['user_id'];
		$log_username = $_SESSION['name'];
		$log_password = $_SESSION['password'];
		
		$admin_ok = admin_check($conx);
		
	}

	// this code checks the student login status
	function student_check($conx){
		$sql = "SELECT fname FROM users WHERE fname ='$name' && accountType='student'";
		$query = mysqli_query($conx,$sql);
		$numrows = mysqli_num_rows($query);
		if($numrows > 0){
			return true;
		}
	}
	
	if (isset($_SESSION['student_user_id']) && isset($_SESSION['fname']) && isset($_SESSION['student_password']) ){
		
		$log_student_id = $_SESSION['student_user_id'];
		$log_student_username = $_SESSION['fname'];
		$log_student_password = $_SESSION['student_password'];
		
		$student_ok = student_check($conx);
		
	}

	// this code checks the marketing_cood login status
	function marketing_cood_check($conx){
		$sql = "SELECT fname FROM users WHERE accountType='marketing_cood' LIMIT 1";
		$query = mysqli_query($conx,$sql);
		$numrows = mysqli_num_rows($query);
		if($numrows > 0){
			return true;
		}
	}
	
	if (isset($_SESSION['marketing_cood_user_id']) && isset($_SESSION['marketing_cood_name']) && isset($_SESSION['marketing_cood_password']) ){
		
		$log_marketing_cood_id = $_SESSION['marketing_cood_user_id'];
		$log_marketing_cood_username = $_SESSION['marketing_cood_name'];
		$log_marketing_cood_password = $_SESSION['marketing_cood_password'];
		
		$marketing_cood_ok = marketing_cood_check($conx);
	}

	// this code checks the marketing_manager login status
	function marketing_manager_check($conx){
		$sql = "SELECT fname FROM users WHERE accountType='marketing_manager' LIMIT 1";
		$query = mysqli_query($conx,$sql);
		$numrows = mysqli_num_rows($query);
		if($numrows > 0){
			return true;
		}
	}
	
	if (isset($_SESSION['marketing_cood_user_id']) && isset($_SESSION['marketing_manager_name']) && isset($_SESSION['marketing_manager_password']) ){
		
		$log_marketing_manager_id = $_SESSION['marketing_manager_user_id'];
		$log_marketing_manager_username = $_SESSION['marketing_manager_name'];
		$log_marketing_manager_password = $_SESSION['marketing_manager_password'];
		
		$marketing_manager_ok = marketing_manager_check($conx);
	}
	// this code checks the guest login status
	function guest_check($conx){
		$sql = "SELECT fname FROM users WHERE accountType='guest' LIMIT 1";
		$query = mysqli_query($conx,$sql);
		$numrows = mysqli_num_rows($query);
		if($numrows > 0){
			return true;
		}
	}
	
	if (isset($_SESSION['guest_id']) && isset($_SESSION['guest_name']) && isset($_SESSION['guest_password']) ){
		
		$log_marketing_manager_id = $_SESSION['guest_id'];
		$log_marketing_manager_username = $_SESSION['guest_name'];
		$log_marketing_manager_password = $_SESSION['guest_password'];
		
		$guest_ok = guest_check($conx);
	}
?>