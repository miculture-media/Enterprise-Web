<?php

//creating variables for db sign in and db name
$errmessage = "Connection could not be established";
$mysql_db = "golden_district";
//myPhpAdmin credentials
$mysql_hostName = "localhost";
$mysql_userName = "root";
$mysql_password = "";

//connection to myPhpAdmin	
$connect = mysql_connect($mysql_hostName, $mysql_userName, $mysql_password);  

//selecting the database
$database = mysql_select_db($mysql_db,$connect);

	
if (!$connect)
	{
	die ($error);
	}	

?>