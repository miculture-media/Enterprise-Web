<?php
	
	$conx = mysqli_connect("localhost","root","","golden_district") or die 
	("Connection was not established");

?>