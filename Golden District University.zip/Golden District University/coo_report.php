<!DOCTYPE html>
<html lang="en">
<head>
<?php
	session_start();
	$temp_stu_id = "";
	$_SESSION['user_id'];
	$_SESSION['uname'];
	$_SESSION['accountType'];

	$temp_stu_id = $_SESSION['user_id'];

	$faculty_as_name2 = $_SESSION['faculty_name'];

	$connect = mysqli_connect("localhost", "root", "", "golden_district");

	
?>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
require "databaseinit.php";
?>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
require "databaseinit.php";
	$comment = "";
	if(isset($_POST['comments_btn']) && isset($_POST['comment_2'])){

			$id1 =preg_replace('#[^0-9]#', '', $_POST['id']);
			$comment = mysql_real_escape_string($_POST['comment_2']);
			$title_id =preg_replace('#[^0-9]#', '', $_POST["contri_id"]);

			if(empty($comment)){
				echo "Please add comment to continue";
							exit();
			} else{
				$sql="UPDATE faculty SET cood_comment ='$comment' WHERE faculty_id = '$title_id'";
							$query=mysql_query($sql);
							echo '
								<script type="text/javascript">
									alert("Commented added");
									window.location = "coo_report.php";
								</script>
							
							';
				}

	}
?>
<title>Dashboard</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/courses.css">
<link rel="stylesheet" type="text/css" href="styles/courses_responsive.css">
</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			
		<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
									<li><div class="question">Have any questions?</div></li>
									<li>
										<i class="fa fa-phone" aria-hidden="true"></i>
										<div>+260 211 *** ***</div>
									</li>
									<li>
										<i class="fa fa-envelope-o" aria-hidden="true"></i>
										<div>info@goldendistrict.uni</div>
									</li>
								</ul>
								<div class="top_bar_login ml-auto">
									<div class="login_button"><a href="logout.php">Logout</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

		<!-- Header Content -->
		<div class="header_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo_container">
								<a href="#">
									<div class="logo_text">Golden District<span> University</span></div>
								</a>
							</div>
							<nav class="main_nav_contaner ml-auto">
								<ul class="main_nav">
									<li><a class="active" href="coo_report.php">Dashboard</a></li>
								</ul>
								
								<!-- Hamburger -->

								<div class="hamburger menu_mm">
									<i class="fa fa-bars menu_mm" aria-hidden="true"></i>
								</div>
							</nav>


						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Header Search Panel -->
		<div class="header_search_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_search_content d-flex flex-row align-items-center justify-content-end">
							<form action="#" class="header_search_form">
								<input type="search" class="search_input" placeholder="Search" required="required">
								<button class="header_search_button d-flex flex-column align-items-center justify-content-center">
									<i class="fa fa-search" aria-hidden="true"></i>
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>			
		</div>			
	</header>

	<!-- Menu -->

	<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
		<div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
		<div class="search">
			<form action="#" class="header_search_form menu_mm">
				<input type="search" class="search_input menu_mm" placeholder="Search" required="required">
				<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
					<i class="fa fa-search menu_mm" aria-hidden="true"></i>
				</button>
			</form>
		</div>																			
		<nav class="menu_nav">
			<ul class="menu_mm">
				<li class="menu_mm"><a href="adminIndex.php">Dashboard</a></li>
				<li class="menu_mm"><a href="#">Add User</a></li></li>
			</ul>
		</nav>
	</div>
	
	<!-- Home -->

	<div class="home">
		<div class="breadcrumbs_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="breadcrumbs">
							<ul>
								<li><a href="adminIndex.php">Home</a></li>
								<li>Dashboard</li>
								<li>Logged in as: <?php echo $_SESSION['uname'];
								?></li>
								<li>Faculty Name : <?php echo $faculty_as_name2; ?></li>
								<li>Account Type: <?php echo $_SESSION['accountType']; ?></li>
								<li>ID : <?php echo $temp_stu_id; ?></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>

	<!-- Courses -->

	<div class="courses">
		<div class="container">
			<div class="row">

				<!-- Courses Main Content -->
				<div class="col-lg-12">
					
					<div class="courses_container">
						<div class="row courses_row">
							
							<!-- Database Entry -->
							<div class="col-lg-12 course_col">
								<div class="course">
									<div class="course_body">
										<h3 class="course_title"><a href="course.html">Viewing all Contributions in Your Faculty</a></h3>
										<div class="course_text">
										<?php  
												  //include_once("conx/conx.php");
												 $output = '';  
												 $sql = "SELECT * FROM faculty WHERE contribution_title IS NOT NULL AND faculty_name ='$faculty_as_name2' ORDER BY faculty_id DESC";  
												 $result = mysql_query($sql);  
												 $output .= '  
													  <div >  
														   <table class="table">  
																<tr>  <th></th>
																	 <th >Faculty Name</th>
																	 <th >Title</th> 
																	 <th >Contribution</th>
																	 <th >Image</th>  
																	 <th >submittedDate</th>
																	 <th >Post Comment</th>
																	 <th >Add/Edit Comment</th>
																	 
																	 
																	 
																</tr>';  
												 if(mysql_num_rows($result) > 0)  
												 {  
													  while($row = mysql_fetch_array($result))  
													  {  
														   $output .= '  
														   <form name="conts_com" method="post" action="coo_report.php">
																<tr><input type="hidden" name="id" value="<?php echo $id; ?>">
																	<td><input type="hidden" name="contri_id" value='.$row["faculty_id"].'></td>
																	<td >'.$row["faculty_name"].'</td>
																	<td >'.$row["contribution_title"].'</td>
																	<td >'.$row["contribution"].'</td>
																	<td >'.$row["image"].'</td>
																	<td >'.$row["submittedDate"].'</td>
																	<td >'.$row["cood_comment"].'</td>
																	<td ><input type="text" name="comment_2" id="comment_2"></input></td>
																	<td ><input type="submit" name="comments_btn" 
																	value="Add Comment" ><a href="coo_report.php.php?id='.$row["faculty_id"].'"></a></input></td>
																	
																										  
																</tr>  </form>
														   ';  
													  }  
													  
												 }  
												 else  
												 {  
													  $output .= '<tr>  
																		  <td colspan="4">Faculty contains no contributions yet.</td>  
																	 </tr>';  
												 }  
												 $output .= '</table>  
													  </div>';  
												 echo $output;  
								 ?>


										</div>
									</div>
								</div>
							</div>
						</div>	

						<div class="row courses_row">
							
							
													</div>	

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


		

			<div class="row copyright_row">
				<div class="col">
					<div class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
						<div class="cr_text"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
						<div class="ml-lg-auto cr_links">
							<ul class="cr_list">
								<li><a href="#">Copyright notification</a></li>
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/courses.js"></script>
</body>
</html>