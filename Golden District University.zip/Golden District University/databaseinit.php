<?php
//creating variables for db sign in and db name
$errmessage = "Connection could not be established";
$mysql_db = "golden_district";
//myPhpAdmin credentials
$mysql_hostName = "localhost";
$mysql_userName = "root";
$mysql_password = "";

//connection to myPhpAdmin	
$connect = mysql_connect($mysql_hostName, $mysql_userName, $mysql_password);  

	
if (!$connect)
	{
	die ($error);
	}	

//selecting the database
$database = mysql_select_db("golden_district",$connect);

//if database does not exist then create it
if (!$database)
	{
	$createQuery = "CREATE DATABASE  `golden_district`";

	if(mysql_query($createQuery)){
		echo "Database successfully created";
		}else{
			echo "Database has not been created";
			}
	}		


$database = mysql_select_db("golden_district",$connect);

				        //course
$create_course="CREATE TABLE IF NOT EXISTS `course` (
  `course_id` varchar(6) NOT NULL,
  `course_name` varchar(40) NOT NULL,
  `faculty_id` int(5) NOT NULL,
  `user_id` int(5) DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  KEY `faculty_id` (`faculty_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;";

$insertCourseBBA ="INSERT INTO `course` (`course_id`, `course_name`, `faculty_id`, `user_id`) VALUES
('100', 'Business Administration', 520, NULL);";

//faculty
$create_faculty="CREATE TABLE IF NOT EXISTS `faculty` (
  `faculty_id` int(8) NOT NULL AUTO_INCREMENT,
  `faculty_name` varchar(15) NOT NULL,
  `marketing_cood` varchar(40) DEFAULT NULL,
  `contribution_title` varchar(20) DEFAULT NULL,
  `contribution` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `submittedDate` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(6) DEFAULT NULL,
  `cood_comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`faculty_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=541 DEFAULT CHARSET=latin1;";

$inserFaculty ="INSERT INTO `faculty` (`faculty_id`, `faculty_name`, `marketing_cood`, `contribution_title`, `contribution`, `image`, `submittedDate`, `user_id`, `cood_comment`) VALUES
(520, 'Business', 'Jaime Felicia', NULL, NULL, NULL, '2019-05-06 21:33:02', 6, NULL),
(521, 'Science', 'Sherlock Walter', 'Unparalleled', 'CATWOE Analysis.docx', NULL, '2019-04-27 20:09:37', 1, NULL),
(522, 'Science', 'Sherlock Walter', 'Afrocentric Pieces', 'COVER PAGES.docx', NULL, '2019-04-27 20:27:32', 5, 'Good content'),
(524, 'Science', 'Sherlock Walter', NULL, NULL, NULL, NULL, 2, NULL),
(537, 'Business', 'Jaime Felicia', 'Paradigm Shift', 'A1-Draw-a-rich-picture-for-the-complete-NSSG-environment.docx', 'sample.jpg', '2019-05-06 15:09:31', 6, 'Educative Piece'),
(538, 'Science', 'Sherlock Walter', 'The power of Speech', 'Power-of-Speech.docx', 'daylight.jpg', '2019-05-06 00:17:47', 2, NULL),
(539, 'Business', 'Jaime Felicia', 'Welcome to JavaWorld', 'Java-FAQs.docx', 'Pizelex.jpg', '2019-05-06 15:08:59', 6, 'Good Article'),
(540, 'Biology', NULL, NULL, NULL, NULL, '2019-04-18 00:00:00', NULL, NULL);";


//user table
$create_users="CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(6) NOT NULL AUTO_INCREMENT,
  `fname` varchar(15) NOT NULL,
  `surname` varchar(15) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `email` varchar(30) NOT NULL,
  `accountType` enum('admin','marketing_cood','marketing_manager','guest','student') NOT NULL,
  `faculty_id` int(8) DEFAULT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `faculty_id` (`faculty_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;";

$insertUsers = "INSERT INTO users (`user_id`, `fname`, `surname`, `gender`, `email`, `accountType`, `faculty_id`, `password`) VALUES
(1, 'admin', '1', 'male', 'admin@gdu.org', 'admin', NULL, 'golden123'),
(2, 'Mwansa', 'Chibale', 'male', 'mwansach@student.org', 'student', 524, 'golden123'),
(3, 'Jaime', 'Felicia', 'Female', 'feliciajai@gdu.org', 'marketing_cood', 520, 'golden123'),
(4, 'James', 'St. Patricks', 'male', 'james@gdu.org', 'marketing_manager', NULL, 'golden123'),
(5, 'Alfred', 'Phiri', 'male', 'alfphi@gdu.org', 'student', 521, 'golden123'),
(6, 'Kelvin', 'Lance', 'male', 'kev@gdu.org', 'student', 520, 'golden123'),
(7, 'guest', '1', 'male', 'guestaccount@golden.uni.edu', 'guest', NULL, 'golden123'),
(8, 'Sherlock', 'Walter', 'Male', 'sw@email.com', 'marketing_cood', 521, 'golden123'),
(9, 'Peter', 'Chu', 'Male', 'pm@examplemail.com', 'marketing_cood', 540, 'golden123'),
(10, 'Franklin', 'Phiri', 'Male', 'fphiri@email.com', 'student', NULL, 'golden123');";

$alter1 = "ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`),
  ADD CONSTRAINT `course_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);";

$alter2 = "ALTER TABLE `faculty`
  ADD CONSTRAINT `user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);";  


$alter3 = "ALTER TABLE `users`
  ADD CONSTRAINT `faculty_fk` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`);";



		
/* $create_faculty1="INSERT INTO `faculty` (`faculty_id`, `faculty_name`, 'marketing_cood', `contribution_title`, `contribution`, `image`, `submittedDate`, `cood_comment`) VALUES ('520', 'Business', 'Jaime Felicia' , NULL, NULL, NULL, CURRENT_TIMESTAMP, NULL);";	

$create_course1="INSERT INTO `course` (`course_id`, `course_name`, `faculty_id`, `user_id`) VALUES ('100', 'Business Administration', '520', NULL);";

$create_admin="INSERT INTO `users` (`user_id`, `fname`, `surname`, `gender`, `email`, `accountType`, `password`) VALUES ('1', 'admin', '1', 'male', 'admin@gdu.org', 'admin', 'golden123');";

$create_student1="INSERT INTO `users` (`user_id`, `fname`, `surname`, `gender`, `email`, `accountType`, `password`) VALUES ('2', 'Mwansa', 'Chibale', 'male', 'mwansach@student.org', 'student', 'golden123');"; 


INSERT INTO `users` (`user_id`, `fname`, `surname`, `gender`, `email`, `accountType`, `password`) VALUES ('3', 'Jaime', 'Felicia', 'Female', 'feliciajai@gdu.org', 'marketing_cood', 'golden123');


INSERT INTO `faculty` (`faculty_id`, `faculty_name`, `marketing_cood`, `contribution_title`, `contribution`, `image`, `submittedDate`, `user_id`, `cood_comment`) VALUES ('521', 'Science', 'Sherlock Walter', 'Unparalleled', 'CATWOE Analysis.docx', NULL, CURRENT_TIMESTAMP, '1', NULL);


INSERT INTO `users` (`user_id`, `fname`, `surname`, `gender`, `email`, `accountType`, `faculty_id`, `password`) VALUES ('5', 'Alfred', 'Phiri', 'male', 'alfphi@gdu.org', 'student', '521', 'golden123'), ('6', 'Kelvin', 'Lance', 'male', 'kev@gdu.org', 'student', '520', 'golden123')

INSERT INTO `users` (`user_id`, `fname`, `surname`, `gender`, `email`, `accountType`, `faculty_id`, `password`) VALUES (NULL, 'guest', '1', 'male', 'guestaccount@golden.uni.edu', 'guest', NULL, 'golden123');

UPDATE `users` SET `faculty_id` = '520' WHERE `users`.`user_id` = 3;

*/

//to confirm if creation of tables was successful
if (mysql_query($create_users,$connect)){ 
   }
   else{
   echo "<p>User table failed due to : " . mysql_error(); + "</p>";
		}   

if (mysql_query($create_faculty,$connect)){ 
  }
else{
   echo "<p>Faculty table failed due to :  " . mysql_error(); + "</p>";
	}

if (mysql_query($create_course,$connect)){ 
  }
else{
   echo "<p>Course table failed due to :  " . mysql_error(); + "</p>";
	}





//insert pre defined data to database
$insertUser1 ="INSERT INTO `users` (`user_id`, `fname`, `surname`, `gender`, `email`, `accountType`, `course_id`, `password`) VALUES ('1', 'admin', '1', 'male', 'admin@gdu.org', 'admin', '000', 'golden123');";