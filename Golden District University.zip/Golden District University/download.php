<?php
error_reporting(E_ALL ^ E_DEPRECATED);
//require "databaseinit.php";
 if (isset($_POST['download_all'])) {
 	$row ='';
 	$dbLink = mysqli_connect("localhost","root","","golden_district") or die 
	("Connection was not established");
   
   //$query = "SELECT contribution, image FROM faculty WHERE contribution_title IS NOT NULL";
   $query = "SELECT contribution, image FROM faculty WHERE contribution_title IS NOT NULL AND contribution IS NOT NULL";
   //$result = $dbLink->query($query);
   $result = mysqli_query($dbLink, $query);
   
   if ($result) {
   	// Make sure the result is valid
            if ($result->num_rows > 0) {
                // Get the row
                $row = mysqli_fetch_assoc($result);

                //zip function

                $zip = new ZipArchive();
                $filename = "Student_Contributions_" .date('Y.m.d H.i.s') . ".zip";

                if ($zip->open($filename, ZIPARCHIVE::CREATE | ZIPARCHIVE::OVERWRITE) !== true) {
                    echo "Cannot Open for writing";
                }


              //  while($row =  mysqli_fetch_assoc($result))  
				//{
				//$ext = $row['contribution'].".doc"; // taking file name from DB and adding extension separately
               	$ext = $row['contribution'].".doc"; // taking file name from DB and adding extension separately
                $ext2 = $row['image'].".jpg";
                $zip->addFromString($ext, $row['contribution']); //adding blob data from DB
                $zip->addFromString($ext2, $row['image']);
                $zip->close();


                header("Content-disposition: inline; filename='.$filename'");
	            header('Content-type: application/zip');
	            header('Pragma: public');
	             readfile($filename);
	           // readfile('contr_docs/'.$filename);
	            unlink($filename);

	             mysqli_free_result($result);
         		 mysqli_close($dbLink);
				//}
               // $ext = $row['contribution'].".doc"; // taking file name from DB and adding extension separately
               // $ext = $row['contribution']; // taking file name from DB and adding extension separately
               // $ext2 = $row['image'];
               // $zip->addFromString($ext, $row['image']); //adding blob data from DB
               // $zip->addFromString($ext2, $row['image']);
               // $zip->close();

       /*         header("Content-disposition: inline; filename='.$filename'");
	            header('Content-type: application/zip');
	            header('Pragma: public');
	             readfile($filename);
	           // readfile('contr_docs/'.$filename);
	            unlink($filename);  */
            }
   }	
		// mysqli_free_result($result);
       //  mysqli_close($dbLink);
}


?>