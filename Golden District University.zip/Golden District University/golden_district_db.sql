-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2019 at 07:10 PM
-- Server version: 5.7.9
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `golden_district`
--
CREATE DATABASE IF NOT EXISTS `golden_district` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `golden_district`;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
CREATE TABLE IF NOT EXISTS `course` (
  `course_id` varchar(6) NOT NULL,
  `course_name` varchar(40) NOT NULL,
  `faculty_id` int(5) NOT NULL,
  `user_id` int(5) DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  KEY `faculty_id` (`faculty_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `course_name`, `faculty_id`, `user_id`) VALUES
('100', 'Business Administration', 520, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
CREATE TABLE IF NOT EXISTS `faculty` (
  `faculty_id` int(8) NOT NULL AUTO_INCREMENT,
  `faculty_name` varchar(15) NOT NULL,
  `marketing_cood` varchar(40) DEFAULT NULL,
  `contribution_title` varchar(20) DEFAULT NULL,
  `contribution` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `submittedDate` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int(6) DEFAULT NULL,
  `cood_comment` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`faculty_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=541 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty_id`, `faculty_name`, `marketing_cood`, `contribution_title`, `contribution`, `image`, `submittedDate`, `user_id`, `cood_comment`) VALUES
(520, 'Business', 'Jaime Felicia', NULL, NULL, NULL, '2019-05-06 21:33:02', 6, NULL),
(521, 'Science', 'Sherlock Walter', 'Unparalleled', 'CATWOE Analysis.docx', NULL, '2019-04-27 20:09:37', 1, NULL),
(522, 'Science', 'Sherlock Walter', 'Afrocentric Pieces', 'COVER PAGES.docx', NULL, '2019-04-27 20:27:32', 5, 'Good content'),
(524, 'Science', 'Sherlock Walter', NULL, NULL, NULL, NULL, 2, NULL),
(537, 'Business', 'Jaime Felicia', 'Paradigm Shift', 'A1-Draw-a-rich-picture-for-the-complete-NSSG-environment.docx', 'sample.jpg', '2019-05-06 15:09:31', 6, 'Educative Piece'),
(538, 'Science', 'Sherlock Walter', 'The power of Speech', 'Power-of-Speech.docx', 'daylight.jpg', '2019-05-06 00:17:47', 2, NULL),
(539, 'Business', 'Jaime Felicia', 'Welcome to JavaWorld', 'Java-FAQs.docx', 'Pizelex.jpg', '2019-05-06 15:08:59', 6, 'Good Article'),
(540, 'Biology', NULL, NULL, NULL, NULL, '2019-04-18 00:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(6) NOT NULL AUTO_INCREMENT,
  `fname` varchar(15) NOT NULL,
  `surname` varchar(15) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `email` varchar(30) NOT NULL,
  `accountType` enum('admin','marketing_cood','marketing_manager','guest','student') NOT NULL,
  `faculty_id` int(8) DEFAULT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `faculty_id` (`faculty_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `fname`, `surname`, `gender`, `email`, `accountType`, `faculty_id`, `password`) VALUES
(1, 'admin', '1', 'male', 'admin@gdu.org', 'admin', NULL, 'golden123'),
(2, 'Mwansa', 'Chibale', 'male', 'mwansach@student.org', 'student', 524, 'golden123'),
(3, 'Jaime', 'Felicia', 'Female', 'feliciajai@gdu.org', 'marketing_cood', 520, 'golden123'),
(4, 'James', 'St. Patricks', 'male', 'james@gdu.org', 'marketing_manager', NULL, 'golden123'),
(5, 'Alfred', 'Phiri', 'male', 'alfphi@gdu.org', 'student', 521, 'golden123'),
(6, 'Kelvin', 'Lance', 'male', 'kev@gdu.org', 'student', 520, 'golden123'),
(7, 'guest', '1', 'male', 'guestaccount@golden.uni.edu', 'guest', NULL, 'golden123'),
(8, 'Sherlock', 'Walter', 'Male', 'sw@email.com', 'marketing_cood', 521, 'golden123'),
(9, 'Peter', 'Chu', 'Male', 'pm@examplemail.com', 'marketing_cood', 540, 'golden123'),
(10, 'Franklin', 'Phiri', 'Male', 'fphiri@email.com', 'student', NULL, 'golden123');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `course`
--
ALTER TABLE `course`
  ADD CONSTRAINT `course_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`),
  ADD CONSTRAINT `course_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `faculty`
--
ALTER TABLE `faculty`
  ADD CONSTRAINT `user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `faculty_fk` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
