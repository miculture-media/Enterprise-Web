<?php
session_start();
// Set Session data to an empty array
$_SESSION = array();

// Destroy the session variables
session_destroy();
// Double check to see if their sessions exists
if(isset($_SESSION['uname']) || isset($_SESSION['name'])){
	echo "Login Failed. Press back and try again";
	exit();
} else {
	header("location: sign.php");
	exit();
} 
?>