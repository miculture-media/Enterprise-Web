The database is created by default when the project is launched for the first time on a machine. But however, for demostration purposes dummy data was already inserted into the database and this can be extracted by importing the "golden_district_db.sql" file and this will bring the database into a state of having data.

The login credentials for the accounts is as follows:

User: admin
Account Type: admin
password: golden123

User: Mwansa
Account Type: student
password: golden123

User: Jaime
Account Type: marketing_cood
password: golden123

User: James
Account Type: marketing_manager
password: golden123

User: Sherlock
Account Type: marketing_cood
password: golden123



Import the database from the 'golden_district.sql' file to run all the database