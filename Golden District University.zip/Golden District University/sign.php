<!DOCTYPE html> 
<html lang="en">
<head>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
/*include_once("check_login.php");

	if($admin_ok == true){
		header("location: adminIndex.php");
		exit();
	}if($student_ok == true){
		header("location: studentsIndex.php");
		exit();
	}else if($marketing_cood_ok == true){
		header("location: coo_report.php");
		exit();
	}else if($marketing_manager_ok == true){
		header("location: all_report.php");
		exit();
	}else if($guest_ok == true){
		header("location: exep_reports.php");
		exit();
	} */


require "databaseinit.php";
$msg = "";

//checking the username and paasword provided
if(isset($_POST['signingIn'])){
	$name = mysql_real_escape_string($_POST['fname']);
	$pass = ($_POST['password']);

	//msg for leaving the password empty
	if($name == "" || $pass == ""){
		echo "<script> alert('Login Failed : Fields are blanks'); </script>";
			}else{

				$sql = "SELECT user_id, fname, password, accountType FROM `users` WHERE fname = '$name' ";
				$query = mysql_query($sql);

				$row = mysql_fetch_row($query);
				$user_id = $row[0];
				$user_name = $row[1];
				$user_pass = $row[2];
				$user_type = $row[3];

				$sql1 = "SELECT faculty_name FROM faculty WHERE user_id = '$user_id'";
				$query21 = mysql_query($sql1);

				$row21 = mysql_fetch_row($query21);
				$faculty_as_name = $row21[0];

				//getting faculty name for coordinator
				$sql12 = "SELECT faculty_name FROM faculty WHERE marketing_cood LIKE '$name%'";
				$query211 = mysql_query($sql12);

				$row211 = mysql_fetch_row($query211);
				$faculty_as_name2 = $row211[0];


						
				$sql_select3="SELECT marketing_cood from faculty WHERE user_id ='$user_id';";
				$query31 = mysql_query($sql_select3);
				//$rowG = mysql_fetch_row($query);
				//$coodName2 = $query ;
				$rowI = mysql_fetch_row($query31);
				$mar_cod2 = $rowI[0];



					if($pass != $user_pass ){
					echo "<script> alert('login failed:please login using a valid username and password'); </script>";
					//exit();
				}else{
					if($user_type=="admin"){
						session_start();
						//assigning session to check if user is logged in 
						$_SESSION['user_id'] = $user_id;
						$_SESSION['fname'] = $user_name;
						$_SESSION['password'] = $user_pass;
						$_SESSION['accountType'] = $user_type;

						// redirect to the user page
						header("location: adminIndex.php");

					}else if($user_type=="student"){
						session_start();
						//assigning session to check if user is logged in 
						$_SESSION['user_id'] = $user_id;
						$_SESSION['uname'] = $user_name;
						$_SESSION['upassword'] = $user_pass;
						$_SESSION['accountType'] = $user_type;						
						$_SESSION['faculty_name'] = $faculty_as_name;
						$_SESSION['marketing_cood'] = $mar_cod2;

						header("location: studentsIndex.php");

					}else if($user_type=="marketing_cood"){
						session_start();
						//assigning session to check if user is logged in 
						$_SESSION['user_id'] = $user_id;
						$_SESSION['uname'] = $user_name;
						$_SESSION['upassword'] = $user_pass;
						$_SESSION['accountType'] = $user_type;

						$_SESSION['faculty_name'] = $faculty_as_name2;
						
						header("location: coo_report.php");
					}else if($user_type=="marketing_manager"){
						session_start();
						//assigning session to check if user is logged in 
						$_SESSION['user_id'] = $user_id;
						$_SESSION['uname'] = $user_name;
						$_SESSION['upassword'] = $user_pass;
						$_SESSION['accountType'] = $user_type;
						

						header("location: all_report.php");
					}else if($user_type=="guest"){
						session_start();
						//assigning session to check if user is logged in 
						$_SESSION['user_id'] = $user_id;
						$_SESSION['uname'] = $user_name;
						$_SESSION['upassword'] = $user_pass;
						

						header("location: exep_reports.php");
					}
					
				
				
					} 

				}

}

?>
<title>Log In</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="styles/responsive.css">
</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			
		<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
									<li><div class="question">Have any questions?</div></li>
									<li>
										<i class="fa fa-phone" aria-hidden="true"></i>
										<div>+260 211 *** ***</div>
									</li>
									<li>
										<i class="fa fa-envelope-o" aria-hidden="true"></i>
										<div>info@goldendistrict.uni</div>
									</li>
								</ul>
								
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>
	<!-- Menu -->

	<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
		<div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
		<div class="search">
			<form action="#" class="header_search_form menu_mm">
				<input type="search" class="search_input menu_mm" placeholder="Search" required="required">
				<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
					<i class="fa fa-search menu_mm" aria-hidden="true"></i>
				</button>
			</form>
		</div>
		<nav class="menu_nav">
			<ul class="menu_mm">
				<li class="menu_mm"><a href="Index.php">Back</a></li>
			</ul>
		</nav>
	</div>
	
	<!-- Features -->

	<div class="features"><div class="logo_container">
								<a href="#">
									<div class="logo_text">Golden District<span> University</span></div>
								</a>
							</div>
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<h2 class="section_title">Sign In</h2><br><br>

						<form id="loginform" method="post" action="sign.php">
						<p><label for="fname">Username</label></p>
						<input name="fname" type="text">

						<p><label for="password">Password</label></p>
						<input name="password" type="password"><br><br>

					<input type="submit" name="signingIn" Value="Sign In">
					</form>

					<br><br><a href="exep_reports.php">Login as GUEST</a>
						</div>
					</div>
				</div>
			</div>
	</div>

	
<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>