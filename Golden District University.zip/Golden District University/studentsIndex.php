<!DOCTYPE html>
<html lang="en">
<head>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
	//check if user is successfully signed in
	require "databaseinit.php";
	
	session_start();
	$temp_stu_id = "";
	$_SESSION['user_id'];
	$_SESSION['uname'];
	$_SESSION['accountType'];

	$temp_stu_id = $_SESSION['user_id'];

	$faculty_as_name1 = $_SESSION['faculty_name'];

	$mar_cod2 = $_SESSION['marketing_cood'];

		
		// Please specify your Mail Server - Example: mail.example.com.
		ini_set("SMTP","smtp.gmail.com");

		// Please specify an SMTP Number 25 and 8889 are valid SMTP Ports.
		ini_set("smtp_port","587");

		// Please specify the return address to use
		ini_set('sendmail_from', 'akalalukamututwa@live.com');




	//require_once "db/addSpecialUsers.php";
	//if we clicked on Upload button 
	if(isset($_POST['addCont']) && isset($_POST['title_cont'])){ 
		 
	    


	  $title_cont = mysql_real_escape_string($_POST['title_cont']);

	  //make the allowed extensions 
	  $goodExtensions = array('.doc', '.docx',);  
	  $facultyName2 = "";
	  $coodName2 = "";




	 //Handling the files
	 $img_errors = array();
	 $doc_errors = array();
	 $errors = array();

	 //for image
	$file_name = $_FILES['pic']['name'];
	$file_size = $_FILES['pic']['size'];
	$file_tmp = $_FILES['pic']['tmp_name'];
	$file_type = $_FILES['pic']['type'];

	//for doc
	$file_name1 = $_FILES['docfile']['name'];
	$file_size1 = $_FILES['docfile']['size'];
	$file_tmp1 = $_FILES['docfile']['tmp_name'];
	$file_type1 = $_FILES['docfile']['type']; 

	//for image
	// new file size in KB
			$kb_size = $file_size/1024;
			// new file size in MB
			$mb_size = $kb_size/1024;	
	
	//for doc		
	// new file size in KB
			$kb_size1 = $file_size1/1024;
			// new file size in MB
			$mb_size1 = $kb_size1/1024;		
			
	//for image		
			// Split the file name into an array
			$split = explode('.',$file_name);
			$file_ext = strtolower(end($split));

	//for doc
	// Split the file name into an array
			$split1 = explode('.',$file_name1);
			$file_ext1 = strtolower(end($split1));
					
	//for image		
			// Return the file name excluding the file extension
			$name = strtolower($split[0]);
			
	//for doc
			// Return the file name excluding the file extension
			$name1 = strtolower($split1[0]); 

	//for image
			$final_name=str_replace(' ','-',$file_name);


	//for doc
			$final_name1=str_replace(' ','-',$file_name1);
	
	//To create a Folder to store the images
			if (!file_exists("contr_docs")) {mkdir("contr_docs", 0755);}
			
			//To create a Folder to store the docs
		//	if (!file_exists("contr_docs")) {mkdir("contr_docs", 0755);}


			if($file_ext == 'jpg' || $file_ext == 'gif' || $file_ext == 'png' || $file_ext1 == 'docx' || $file_ext1 == 'doc' ){
		//for images		
			if($mb_size > 10) {$errors[] = 'File size must be under 10mb';}
		//for docs
		//	if($mb_size1 > 20) {$doc_errors[] = 'File size must be under 20mb';}
					
			 
			if(empty($img_errors) && empty($docs_errors)) {
				$url = "contr_docs/$final_name";

				//upload both the files
						if (move_uploaded_file($file_tmp,$url)){
					}else{
							echo $error;

						}if(empty($docs_errors)){
							$url = "contr_docs/$final_name1";
								//upload the docx file
								if(move_uploaded_file($file_tmp1, $url)){
									
									//header("Location: studentsIndex.php");
								}
							} 
			//	else{ foreach ($errors as $error) {
			//		echo $error, '<br />';}
					
					// }

			}

			}







//from here
	 //check if there are any empty fields
	if(empty($title_cont)){//echo ("Please make sure you add a title");
		 echo "<script> alert('Pleases make sure you add a title'); </script>";
		 //header("Location: studentsIndex.php");
		}else{
			//Insert Query
							$sql_insert="INSERT INTO faculty (faculty_name,marketing_cood,contribution_title,contribution,image,user_id) 
							VALUES('$faculty_as_name1','$mar_cod2','$title_cont','$final_name1','$final_name','$temp_stu_id')";
							$query2 = mysql_query($sql_insert);


							$from = "goldendistrict@email.edu";

							$to = "akalalukamututwa@gmail.com";
							$subject = "Article submission";
							$subject2 = "Article submission";

							$message = "Submission was made to the site";
					    	$message2 = "Another message just to confirm it was sent the first time";

					    	$headers = "From:" . $from;
						    $headers2 = "From:" . $to;
						    mail($to,$subject,$message,$headers);
						    mail($from,$subject2,$message2,$headers2); // sends a copy of the message to the sender

				
						/*	echo '<script type="text/javascript">
									alert("Your Content has been Uploaded. Thank you for your Submission!");
									window.location = "studentsIndex.php";
								</script>'; */

								echo '<script type="text/javascript">
									alert("You provided faculty name %s ");
									window.location = "studentsIndex.php";
								</script>';
		}

		
	//upto here					

			 



	}

	



























?>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
require "databaseinit.php";
?>
<?php
		
		

		if(isset($_POST['submitmail'])){	
		
	}
?>
<title>Student Dashboard</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Unicat project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="plugins/colorbox/colorbox.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/courses.css">
<link rel="stylesheet" type="text/css" href="styles/courses_responsive.css">
<script type="text/javascript" src="one.js"></script>
<script language="javascript">

function enableField()
{
document.detailsForm.addCont.disabled=false;
}
 
</script>



</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			
		<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<ul class="top_bar_contact_list">
									<li><div class="question">Have any questions?</div></li>
									<li>
										<i class="fa fa-phone" aria-hidden="true"></i>
										<div>+260 211 *** ***</div>
									</li>
									<li>
										<i class="fa fa-envelope-o" aria-hidden="true"></i>
										<div>info@goldendistrict.uni</div>
									</li>
								</ul>
								<div class="top_bar_login ml-auto">
									<div class="login_button"><a href="sign.php">Logout</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

		<!-- Header Content -->
		<div class="header_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_content d-flex flex-row align-items-center justify-content-start">
							<div class="logo_container">
								<a href="#">
									<div class="logo_text">Golden District<span> University</span></div>
								</a>
							</div>
							<nav class="main_nav_contaner ml-auto">
								<ul class="main_nav">
									<li class="active"><a href="studentsIndex.php">Dashboard</a></li>
								</ul>
								<div class="search_button"><i class="fa fa-search" aria-hidden="true"></i></div>

								<!-- Hamburger -->

								<div class="hamburger menu_mm">
									<i class="fa fa-bars menu_mm" aria-hidden="true"></i>
								</div>
							</nav>


						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Header Search Panel -->
		<div class="header_search_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="header_search_content d-flex flex-row align-items-center justify-content-end">
							<form action="#" class="header_search_form">
								<input type="search" class="search_input" placeholder="Search" required="required">
								<button class="header_search_button d-flex flex-column align-items-center justify-content-center">
									<i class="fa fa-search" aria-hidden="true"></i>
								</button>
							</form>
						</div>
					</div>
				</div>
			</div>			
		</div>			
	</header>

	<!-- Menu -->

	<div class="menu d-flex flex-column align-items-end justify-content-start text-right menu_mm trans_400">
		<div class="menu_close_container"><div class="menu_close"><div></div><div></div></div></div>
		<div class="search">
			<form action="#" class="header_search_form menu_mm">
				<input type="search" class="search_input menu_mm" placeholder="Search" required="required">
				<button class="header_search_button d-flex flex-column align-items-center justify-content-center menu_mm">
					<i class="fa fa-search menu_mm" aria-hidden="true"></i>
				</button>
			</form>
		</div>
		<nav class="menu_nav">
			<ul class="menu_mm">
				<li class="menu_mm"><a href="studentsIndex.php">Home</a></li>
				<li class="menu_mm"><a href="logout.php">Logout</a></li>
			</ul>
		</nav>
	</div>
	
	<!-- Home -->

	<div class="home">
		<div class="breadcrumbs_container">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="breadcrumbs">
							<ul>
								<li><a href="#">Home</a></li>
								<li>Dashboard</li>
								<li>Logged in as: <?php echo $_SESSION['uname'];
								?></li>
								<li>Account Type: <?php echo $_SESSION['accountType']; ?></li>
								<li>ID : <?php echo $temp_stu_id; ?></li>
								<li>Faculty Name : <?php echo $faculty_as_name1; ?></li>
								<li>Cood Name : <?php echo $mar_cod2; ?></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>

	<!-- Courses -->

	<div class="courses">
		<div class="container">
			<div class="row">

				<!-- Courses Main Content -->
				<div class="col-lg-12">
					<div class="courses_search_container">
						<h2>You can upload your contribution here.</h2>

				<form enctype="multipart/form-data" name="detailsForm" method="POST" action="studentsIndex.php">

				Choose file for upload<br><br>
				<div id="float-container" class="float-container">
						<label for="contr_title">Title of Article</label><br>
						<input id="contr_title" name="title_cont" type="text">
					</div><br>

					<label for="picture">Add an Image </label><br/>
					<input id="file" type="file" name="pic" /><br/><br/> <!-- <td ><img src="contr_pics/'.$row["image"].'" width="70" height="30" title="picture" alt="contribution picture"></td> 
									 -->
				
				<label for="docfile">Choose your .doc(x) file </label><br/>
				<input accept=".docx" name="docfile" size="15" type="file" /><br><br>				

			    <input id="subby" type="checkbox" name="TCs" onClick ="javascript:enableField()"> I agree to all Terms and Conditions<br><br>

			<input type="submit" class="courses_search_button ml-auto" value="Upload" name="addCont" id="addCont" disabled="true"><br><br>


						</form>

					</div>
					<div class="courses_container">
						<div class="row courses_row">
							
							<!-- Database Entry -->
							<div class="col-lg-12 course_col">
								<div class="course">
									<div class="course_body">
										<h3 class="course_title"><a href="#">Your Current Contributions</a></h3>
										<div class="course_teacher">All your titles</div>
										<div class="course_text">
					<?php  
												  //to show all the contributions made by the current user
												 $output = '';   
											//	 $sql = "SELECT user_id, contribution_title,contribution,image,submittedDate FROM faculty WHERE cood_comment IS NULL AND contribution_title IS NOT NULL AND user_id ='6' ORDER BY faculty_id DESC"; 
												 $sql = "SELECT user_id, contribution_title,contribution,image,submittedDate FROM faculty WHERE  contribution_title IS NOT NULL AND user_id ='$temp_stu_id' ORDER BY faculty_id DESC";
												 $result = mysql_query($sql);  
												 $EmptyText ="No Comment Available";
												 $output .= '  
													  <div >  
														   <table class="table">  
																<tr>  
																	 <th >Title</th> 
																	 <th >Contribution</th>
																	 <th >Image</th>  
																	 <th >submittedDate</th>
																	 <th >Comment</th>
																	 
																</tr>';  
												 if(mysql_num_rows($result) > 0)  
												 {  
													  while($row = mysql_fetch_array($result))  
													  {  
														   $output .= '  
																<tr>
																	<td >'.$row["contribution_title"].'</td>
																	<td >'.$row["contribution"].'</td>
																	<td >'.$row["image"].'</td>
																	<td >'.$row["submittedDate"].'</td>
																	<td >'.$EmptyText.'</td>			  
																</tr>  
														   ';  
													  }  
													  
												 }  
												 else  
												 {  
													  $output .= '<tr>  
																		  <td colspan="4">You have no submissions yet</td>  
																	 </tr>';  
												 }  
												 $output .= '</table>  
													  </div>';  
												 echo $output;  
								 ?>




										</div>
									</div>
								</div>
							</div>

							
						</div>
						
						</div>
					</div>
				</div>

				<!-- Courses Sidebar -->
				<div class="col-lg-4">
					<div class="sidebar">

						

						<!-- Banner -->
						<div class="sidebar_section">
							
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Footer -->

	<footer class="footer">
		<div class="footer_background" style="background-image:url(images/footer_background.png)"></div>
		<div class="container">
			<div class="row footer_row">
				<div class="col">
					<div class="footer_content">
						<div class="row">

							<div class="col-lg-3 footer_col">
					
								<!-- Footer About -->
								<div class="footer_section footer_about">
									<div class="footer_logo_container">
										<a href="#">
											<div class="footer_logo_text">Golden District <span>University</span></div>
										</a>
									</div>
									<div class="footer_about_text">
										<p>Shaping the Frontiers of Education</p>
									</div>
									<div class="footer_social">
										<ul>
											<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
											<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
										</ul>
									</div>
								</div>
								
							</div>

							<div class="col-lg-3 footer_col">
					
								<!-- Footer Contact -->
								<div class="footer_section footer_contact">
									<div class="footer_title">Contact Us</div>
									<div class="footer_contact_info">
										<ul>
											<li>Email: info@goldendistrict.uni</li>
											<li>Phone:  +260 211 *** ***</li>
										</ul>
									</div>
								</div>
								
							</div>

							<div class="col-lg-3 footer_col">							<!-- Footer links -->
								<div class="footer_section footer_mobile">
									<div class="footer_title">Mobile</div>
									<div class="footer_mobile_content">
										<div class="footer_image"><a href="#"><img src="images/mobile_1.png" alt=""></a></div>
										<div class="footer_image"><a href="#"><img src="images/mobile_2.png" alt=""></a></div>
									</div>
								</div>
								
							</div>

						</div>
					</div>
				</div>
			</div>

			<div class="row copyright_row">
				<div class="col">
					<div class="copyright d-flex flex-lg-row flex-column align-items-center justify-content-start">
						<div class="cr_text"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></div>
						<div class="ml-lg-auto cr_links">
							<ul class="cr_list">
								<li><a href="#">Copyright notification</a></li>
								<li><a href="#">Terms of Use</a></li>
								<li><a href="#">Privacy Policy</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="plugins/parallax-js-master/parallax.min.js"></script>
<script src="plugins/colorbox/jquery.colorbox-min.js"></script>
<script src="js/courses.js"></script>
</body>
</html>